#include<stdio.h>
#define PGSIZE          4096    // bytes mapped by a page
#define PGROUNDDOWN(a) (((a)) & ~(PGSIZE-1))    //往低地址处对齐4k地址
#define PGROUNDUP(sz)  (((sz)+PGSIZE-1) & ~(PGSIZE-1))   //往高地址处对齐4k地址
#define KERNBASE 0x100F         // First kernel virtual address 可以尝试其它地址值
typedef unsigned int   uint;
  
int main()
{
	void *va;
	va = (void*)KERNBASE;
	char *a, *b;
	a = (char*)PGROUNDDOWN((uint)va);
	b = (char*)PGROUNDUP((uint)va);
	printf("PGROUNDDOWN=%x \nPGROUNDUP=%x\n",a,b);
	return 0;
}