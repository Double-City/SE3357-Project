#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char **argv) {
	int fathertochild[2];
    int childtofather[2];
	pipe(fathertochild); 
	pipe(childtofather); 
	
	if(fork()) { 
        char buffer;
		write(fathertochild[1], "!", 1); 
		read(childtofather[0], &buffer, 1); 
		printf("%d: received pong\n", getpid()); 
		wait(0);
	} else { 
		char buffer;
		read(fathertochild[0], &buffer, 1);
		printf("%d: received ping\n", getpid());
		write(childtofather[1], &buffer, 1); 
	}
	exit(0);
}