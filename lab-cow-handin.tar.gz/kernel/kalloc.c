// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole PGSIZE-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;
} kmem;

struct {
  struct spinlock lock;
  int cnt[PHYSTOP/4096];
}ref;

int getcnt(void* pa){
  return ref.cnt[(uint64) pa / 4096];
}

void
kinit()
{
  
  initlock(&ref.lock, "kref");
  initlock(&kmem.lock, "kmem");
  freerange(end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE){
    ref.cnt[(uint64)p / 4096] = 1;
    kfree(p);
  }
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");
  
  // 引用计数为0才free掉
  acquire(&ref.lock);
  if(--ref.cnt[(uint64)pa / 4096] == 0){//引用计数-1
    release(&ref.lock);
      // Fill with junk to catch dangling refs.
    memset(pa, 1, PGSIZE);

    r = (struct run*)pa;

    acquire(&kmem.lock);
    r->next = kmem.freelist;
    kmem.freelist = r;
    release(&kmem.lock);
  }else release(&ref.lock);
}


// Allocate one PGSIZE-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if(r){
    uint64 pi = (uint64) r / PGSIZE;
    acquire(&(ref.lock));
    //初始置为1
    ref.cnt[pi] = 1;
    release(&(ref.lock));

    kmem.freelist = r->next;
  
  }
    
  release(&kmem.lock);

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
  return (void*)r;
}


int
addref(void* pa)
{
  if( (uint64) pa % PGSIZE || (char*)pa < end || (uint64) pa > PHYSTOP) return -1;
  acquire(&ref.lock);
  ++ref.cnt[(uint64) pa / PGSIZE];
  release(&ref.lock);
  return 0;
}


/*
int subref(void *pa){
  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    return -1;
  acquire(&ref.lock);
  --ref.count[(uint64)pa / PGSIZE];
  release(&ref.lock);
  return 0;
}
*/

int
is_cowpage(pagetable_t pagetable, uint64 va)
{
  if(va > MAXVA) return -1;
  pte_t *pte = walk(pagetable, va, 0);
  if(pte == 0) return -1;
  if((*pte&PTE_V) == 0) return -1;
  return (*pte & PTE_COW) ? 0 : -1; 
}

// 给cow page分配物理页
void*
cow_alloc(pagetable_t pagetable, uint64 va)
{
  if(va % PGSIZE != 0) return 0;
  uint64 pa = walkaddr(pagetable, va);
  if(pa == 0) return 0;

  pte_t *pte = walk(pagetable, va, 0);
  if(getcnt((char*)pa) == 1){ // 计数为1，标记为W和非cow
    *pte |= PTE_W;
    *pte &= ~PTE_COW;
    return (void*)pa; 
  }else{
    // 有多个进程指向这个物理页面的情况
    char* mem;
    if(!(mem=kalloc())) return 0;
    *pte &= ~PTE_V;
    // 分配新的物理页并且把内容复制过去
    memmove(mem, (char*)pa, PGSIZE);
    
    // W, not COW
    if(mappages(pagetable, va, PGSIZE, (uint64)mem, (PTE_FLAGS(*pte) | PTE_W) & ~PTE_COW) != 0){
      kfree(mem);
      *pte &= ~PTE_V;
      return 0;
    }

    kfree((char*)PGROUNDDOWN(pa));
    return mem;
  }
}
